<?php if (!defined('FLUX_ROOT')) exit; ?>
<h2>About this Addon</h2>

<p>This addon was developed around 2013 for its own purposes, and later put up for sale on the brAthena forum,for personal reasons the sale was closed. In 2014 I decided to make it available for free as a gesture of thanks  to all Ragnarok emulator development communities for their knowledge,it is free for the use that suits you, it has been fully updated and is now in version 2.2 with fixed problems and new functions.</p> 
<p>Facilitates all donation management for servers usingthe FluxCP control panel integrating the PagSeguro API, automating the entire donations process and generating statistics for the server with security.</p>
<p>The installation process follows the same system as other addons for the FluxCP panel,  the account configuration on PagSeguro can be found in the topic of downloading it and inside the compressed file.</p>
<p>Special thanks to <a href="http://herc.ws/board/user/468-oscar171/">oscar171</a>, for insisting on updating and providing test hosting for updating the addon.</p>
<p>If you feel free to donate any amount as thanks for the release and development of this Addon, click on the button below. I will be very grateful for this gesture.</p>
<p><a href="https://forum.brathena.org/index.php?/profile/17-fallenangel~/">Lilium Sancta</a>.</p>

<form action="https://pagseguro.uol.com.br/checkout/v2/donation.html" method="post" align="center">
	<input type="hidden" name="currency" value="BRL" />
	<input type="hidden" name="receiverEmail" value="inu-kai@hotmail.com" />
	<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/doacoes/94x52-doar-assina.gif" name="submit" alt="Pague com PagSeguro - é rápido, grátis e seguro!" />
</form>


