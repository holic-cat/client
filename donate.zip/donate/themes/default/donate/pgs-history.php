<?php if (!defined('FLUX_ROOT')) exit; ?>
<h2>Payment History</h2>
<h3>Transactions: Pending</h3>
<?php if ($pendentes): ?>
<p>You have <?php echo number_format($pendenteTotal);
echo ($pendenteTotal > 1)?(' pending transactions'):(' pending transaction'); ?>.</p>
<table class="vertical-table">
	<tr>
		<th>Donation date</th>
		<th>E-mail</th>
		<th>Type</th>
		<th>Value</th>
	</tr>
	<?php foreach ($pendentes as $pendente): ?>
	<tr>
		<td><?php echo $this->formatDateTime($pendente->payment_date) ?></td>
		<td><?php echo htmlspecialchars($pendente->email) ?></td>
		<td><?php echo htmlspecialchars('Received by '.$pendente->payment_type) ?></td>
		<td>R$ <?php echo htmlspecialchars($this->formatCurrency($pendente->payment)) ?></td>
	</tr>
	<tr>
		<td colspan="4" style="color:Orange">
			↳ Your donation has status (<?php $status = Flux::config('PagSeguroStatus')->toArray();
			echo htmlspecialchars($status[$pendente->payment_status]) ?>) on PagSeguro.
		</td>
	</tr>
	<?php endforeach ?>
</table>
<?php else: ?>
<p>You have no pending transactions.</p>
<?php endif ?>

<h3>Transactions: Approved</h3>
<?php if ($aprovadas): ?>
<p>You have <?php echo number_format($aprovadaTotal);
echo ($aprovadaTotal > 1)?(' approved transactions'):(' approved transaction'); ?>.</p>
<table class="vertical-table">
	<tr>
		<th>Donation date</th>
		<th>E-mail</th>
		<th>Type</th>
		<th>Value</th>
	</tr>
	<?php foreach ($aprovadas as $aprovada): ?>
	<tr>
		<td><?php echo $this->formatDateTime($aprovada->payment_date) ?></td>
		<td><?php echo htmlspecialchars($aprovada->email) ?></td>
		<td><?php echo htmlspecialchars('Received by '.$aprovada->payment_type) ?></td>
		<td>USD $<?php echo htmlspecialchars($this->formatCurrency($aprovada->payment)) ?></td>
	</tr>
	<tr>
		<td colspan="4" style="color:MediumSeaGreen">
			↳ Your donation has status (<?php $status = Flux::config('PagSeguroStatus')->toArray();
			echo htmlspecialchars($status[$aprovada->payment_status]) ?>) on PagSeguro.
		</td>
	</tr>
	<?php endforeach ?>
</table>
<?php else: ?>
<p>You have no approved transactions.</p>
<?php endif ?>

<h3>Transactions: Failures</h3>
<?php if ($recusadas): ?>
<p>You have <?php echo number_format($recusadaTotal);
echo ($recusadaTotal > 1)?(' failed transactions'):(' failed transaction'); ?>.</p>
<table class="vertical-table">
	<tr>
		<th>Donation date</th>
		<th>E-mail</th>
		<th>Type</th>
		<th>Value</th>
	</tr>
	<?php foreach ($recusadas as $recusada): ?>
	<tr>
		<td><?php echo $this->formatDateTime($recusada->payment_date) ?></td>
		<td><?php echo htmlspecialchars($recusada->email) ?></td>
		<td><?php echo htmlspecialchars('Received by '.$recusada->payment_type) ?></td>
		<td>USD $<?php echo htmlspecialchars($this->formatCurrency($recusada->payment)) ?></td>
	</tr>
	<tr>
		<td colspan="4" style="color:Tomato">
			↳ Your donation has status(<?php $status = Flux::config('PagSeguroStatus')->toArray();
			echo htmlspecialchars($status[$recusada->payment_status]) ?>) on PagSeguro.
		</td>
	</tr>
	<?php endforeach ?>
</table>
<?php else: ?>
<p>You have no failed transactions.</p>
<?php endif ?>