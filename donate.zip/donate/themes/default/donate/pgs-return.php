<?php if (!defined('FLUX_ROOT')) exit; ?>
<h2>We appreciate your donation</h2>

<?php if (!empty($errorMessage)): ?>
		<p class="red"><?php echo htmlspecialchars($errorMessage) ?></p>
<?php endif ?>

<meta http-equiv="refresh" content="10; url=<?php echo $this->url('pagseguro', 'history', array('_host' => true)); ?>" />

<p>Thank you for your donation <?php echo htmlspecialchars($session->account->userid) ?>, it is very importantfor us and will be used to improve our servers.
Once approved by the Paypal system, your credits will be automatically added to your account.</p>
<p>You are being redirected to the Paypal History page to view the status of your donation.</p>